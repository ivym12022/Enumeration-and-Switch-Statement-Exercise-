import UIKit

enum SandwichOptions {
    case SweetSavory
    case Smokey
    case SpicyCrunchy
}
var SandwichOfChoice = SandwichOptions.SpicyCrunchy

switch SandwichOfChoice {

case .SweetSavory:
    print ("Brown Sugar BLT with mayo on toasted rye bread")
case .Smokey:
    print ("Smoked Chipotle Chicken Sandwich on a toasted bun with pepper jack cheese, fried egg, green tomatos, kale and chipotle mayo")
case .SpicyCrunchy:
    print ("Italian BMT on Italian bread with provelone cheese, lettuce, red tomato, red onions, green peppers, pickles and mustard. Coated in vinegarette and oregano")
}
